package transport;

public enum EventType {
    TIMERINTERRUPT, FROMAPP, FROMNETWORK;
}
